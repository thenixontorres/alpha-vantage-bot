<div class="form-group col-md-12">
  {{Form::text('key', null, ['class'=> 'form-control typeahead', 'placeholder'=>'Llave','required',])}}
</div>

<div class="form-group col-md-12">
  {{Form::text('email', null, ['class'=> 'form-control typeahead', 'placeholder'=>'Correo','required',])}}
</div>

<div class="form-group col-md-12">
  {{Form::text('name', null, ['class'=> 'form-control typeahead', 'placeholder'=>'Nombre','required',])}}
</div>