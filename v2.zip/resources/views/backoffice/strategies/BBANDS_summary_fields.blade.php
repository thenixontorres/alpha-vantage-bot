<p>
	<strong> Temporalidad:  </strong> {{ $settings_array['BBANDS']['request_data']['interval'] }}</strong>
</p>

<p>
	<strong> Peridos:  </strong> {{ $settings_array['BBANDS']['request_data']['time_period'] }}</strong>
</p>

<p>
	<strong> Banda alta:  </strong> {{ $settings_array['BBANDS']['request_data']['nbdevup'] }}</strong>
</p>

<p>
	<strong> Banda baja:  </strong> {{ $settings_array['BBANDS']['request_data']['nbdevdn'] }}</strong>
</p>