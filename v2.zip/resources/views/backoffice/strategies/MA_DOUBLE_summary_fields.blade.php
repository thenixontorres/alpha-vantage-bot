
<p>
	<strong> Temporalidad:  </strong> {{ $settings_array['MA_DOUBLE']['request_data']['interval'] }}</strong>
</p>

<p>
	<strong> MA Lenta:  </strong> {{ $settings_array['MA_DOUBLE']['request_data']['slow']['function'] }} / {{ $settings_array['MA_DOUBLE']['request_data']['slow']['time_period'] }} </strong>
</p>

<p>
	<strong> MA Rapida:  </strong> {{ $settings_array['MA_DOUBLE']['request_data']['fast']['function'] }} / {{ $settings_array['MA_DOUBLE']['request_data']['fast']['time_period'] }} </strong>
</p>