<p>
	<strong> Temporalidad:  </strong> {{ $settings_array['STOCH']['request_data']['interval'] }}</strong>
</p>

<p>
	<strong> K:  </strong> {{ $settings_array['STOCH']['request_data']['slowkperiod'] }}</strong>
</p>

<p>
	<strong> D:  </strong> {{ $settings_array['STOCH']['request_data']['slowdperiod'] }}</strong>
</p>

<p>
	<strong> Smooth:  </strong> {{ $settings_array['STOCH']['request_data']['fastkperiod'] }}</strong>
</p>


