
<p>
	<strong> Temporalidad:  </strong> {{ $settings_array['MA_SINGLE']['request_data']['interval'] }}</strong>
</p>


<p>
	<strong> MA:  </strong> {{ $settings_array['MA_SINGLE']['request_data']['function'] }} / {{ $settings_array['MA_SINGLE']['request_data']['time_period'] }} </strong>
</p>

