
<p>
	<strong> Temporalidad:  </strong> {{ $settings_array['RSI']['request_data']['interval'] }}</strong>
</p>

<p>
	<strong> Peridos:  </strong> {{ $settings_array['RSI']['request_data']['time_period'] }}</strong>
</p>

