<table class="table table-bordered table-sm pt-5" id="{{$strategy->code}}_table">
    <thead>
       
    </thead>
  
    <tbody>
       
    </tbody>
</table>