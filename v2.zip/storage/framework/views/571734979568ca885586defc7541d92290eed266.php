<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center pt-5" >
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"> Configuración del sistema </div>
                <div class="card-body">
                  <?php echo Form::model($setting, ['route' => ['backoffice.settings.update', $setting], 'method' => 'patch']); ?>

                      
                    <?php echo $__env->make('backoffice.settings.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <div class="form-group row mb-0">
                      <div class="col-md-12">
                          <center>  
                              <a class="btn btn-danger" href="<?php echo e(route('backoffice.index')); ?>">Volver</a>
                              <button type="submit" class="btn btn-primary">
                                  Actualizar
                              </button>
                          </center>
                      </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/settings/index.blade.php ENDPATH**/ ?>