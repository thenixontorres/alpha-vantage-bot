<?php $__env->startSection('content'); ?>
	<style>
		.table {
		    width: 100%;
		    margin-bottom: 1rem;
		    color: #212529;
		}
		.table-bordered {
		    border: 1px solid #dee2e6;
		}
		th {
			border: 1px solid #dee2e6;
		}
		td {
			border: 1px solid #dee2e6;
		}
	</style>

	<div style="font-size: 14px;">
		<h4>Nueva Alerta encontrada</h4>

		<table class="table table-bordered">
		    <thead>
		        <tr>
		            <th>Fecha</th>
		            <th>Activo</th>
		            <th>Estrategia</th>
		            <th>Resumen</th>
		            <th>Tipo</th>
		        </tr>
		    </thead>
		    <tbody>
	       		<tr>
		          <td><?php echo e($signal->time_signal); ?></td>
		       		<td><?php echo e($signal->scanner->asset->name); ?></td>
		       		<td>
		       			<?php $__currentLoopData = $signal->scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		                 	<span class="badge badge-info"><?php echo e($strategy->title); ?> </span>

		              	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		       		</td>
		       		<td>
		       			<?php $__currentLoopData = $signal->scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                	<?php echo $__env->make('backoffice.strategies.'.$strategy->summary_fields, ['settings_array'=> $signal->scanner->settings_array], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		       		</td>
		       		<td>
		       			<?php echo $signal->type; ?>

		       		</td>
		        </tr>
		    </tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.emails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/emails/signalNotificationMail.blade.php ENDPATH**/ ?>