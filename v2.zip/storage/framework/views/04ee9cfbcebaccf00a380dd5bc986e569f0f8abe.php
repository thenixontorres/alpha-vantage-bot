
<div class="form-group col-md-12">
	<?php echo e(Form::label('fastkperiod','Smooth:')); ?>

    <?php echo e(Form::number('fastkperiod' ,$scanner->settings_array['STOCH']['request_data']['fastkperiod'], ['class'=> 'form-control', 'placeholder'=>'Solo numeros enteros', 'required'])); ?>

</div>


<div class="form-group col-md-6">
	<?php echo e(Form::label('slowkperiod','MA (K):')); ?>

    <?php echo e(Form::number('slowkperiod' ,$scanner->settings_array['STOCH']['request_data']['slowkperiod'], ['class'=> 'form-control', 'placeholder'=>'Solo numeros enteros', 'required'])); ?>

</div>


<div class="form-group col-md-6">
	<?php echo e(Form::label('slowdperiod','MA (D):')); ?>

    <?php echo e(Form::number('slowdperiod' ,$scanner->settings_array['STOCH']['request_data']['slowdperiod'], ['class'=> 'form-control', 'placeholder'=>'Solo numeros enteros', 'required'])); ?>

</div>



<div class="form-group col-md-6">
	<?php echo e(Form::label('slowkmatype','Tipo de MA (K):')); ?>

    <?php echo e(Form::select('slowkmatype' , $scanner->settings_array['STOCH']['indicators_allow'] ,$scanner->settings_array['STOCH']['request_data']['slowkmatype'], ['class'=> 'form-control', 'placeholder'=>'Seleccione un tipo', 'required'])); ?>

</div>

<div class="form-group col-md-6">
	<?php echo e(Form::label('slowdmatype','Tipo de MA (D):')); ?>

    <?php echo e(Form::select('slowdmatype' , $scanner->settings_array['STOCH']['indicators_allow'] ,$scanner->settings_array['STOCH']['request_data']['slowdmatype'], ['class'=> 'form-control', 'placeholder'=>'Seleccione un tipo', 'required'])); ?>

</div>

<?php echo e(Form::hidden('function', $scanner->settings_array['STOCH']['request_data']['function'])); ?>


<?php echo e(Form::hidden('symbol', $scanner->settings_array['STOCH']['request_data']['symbol'])); ?>


<?php echo e(Form::hidden('interval', $scanner->settings_array['STOCH']['request_data']['interval'])); ?>


<?php echo e(Form::hidden('code', 'STOCH')); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/STOCH_setting_fields.blade.php ENDPATH**/ ?>