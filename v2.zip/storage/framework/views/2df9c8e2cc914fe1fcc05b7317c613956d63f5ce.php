<table class="table table-bordered table-sm" id="table">
    <thead>
        <tr>
            <th>Codigo</th>
            <th>Titulo</th>
            <th>Estatus</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       		<tr>
          		<td><?php echo e($strategy->code); ?></td>
          		<td><?php echo e($strategy->title); ?></td>
       		
		        <td>
		            <?php if($strategy->status == 'on'): ?>
		            	<span class="badge badge-success">Activa</span>
					<?php else: ?>	
						<span class="badge badge-warning">Inactiva</span>
		            <?php endif; ?>
		        </td>
				<td>
		            <?php if($strategy->status == 'off'): ?>
		              
			            <?php echo Form::model($strategy, ['route' => ['admin.strategies.update', $strategy], 'method' => 'patch']); ?>


			              <?php echo Form::hidden('status', 'on'); ?>

			              
			              <button class="btn btn-pill btn-primary"><i class="fa fa-check"></i></button>

			            <?php echo Form::close(); ?>

					
					<?php else: ?>

			            <?php echo Form::model($strategy, ['route' => ['admin.strategies.update', $strategy], 'method' => 'patch']); ?>


			              <?php echo Form::hidden('status', 'off'); ?>

			              
			              <button class="btn btn-pill btn-danger"><i class="fa fa-close"></i></button>
			              
			            <?php echo Form::close(); ?>


		            <?php endif; ?>
         		</td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="<?php echo e(asset('js/default_datatable.js')); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/strategies/table.blade.php ENDPATH**/ ?>