<?php $__env->startSection('title', $scanner->merged_symbols); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center" >
        <div class="col-md-12">
            <div class="card">
                <div class="card-header border-0">
                    <div class="custom-title-wrap bar-info">
                        <div class="custom-title">
                            <h4> <?php echo e($scanner->merged_symbols); ?> :
            
                                <?php $__currentLoopData = $scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <span class="badge badge-info">   <?php echo e($strategy->title); ?></span> 
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </h4>
                        </div>
                    </div>
                </div>                
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	                    <div class="col-md-<?php echo e($scanner->count_cols); ?>">
                                <?php echo $__env->make('backoffice.scanners.alerts_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    						</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="row pt-4">
                 <div class="col-md-12">
                    <a class="btn btn-pill btn-danger" href="<?php echo e(route('backoffice.scanners.index', $scanner->scanner_type)); ?>">Volver</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
    
    <script src="<?php echo e(asset('js/push.min.js')); ?>"></script> 

    
   <script> 
        $(document).ready(function(){

            console.log('starting...');
            
            
            buildHead();
            
            
            applyStrategy();
            
            var miliseconds = '<?php echo e($scanner->interval_ms); ?>';
            
            
            setInterval(applyStrategy, miliseconds);

            /*Consulta de la estrategia*/
            function applyStrategy()
            {
                console.log('getting...');
                var route = '<?php echo e(route('backoffice.scanners.apply', $scanner)); ?>';
                $.get(route).then(setSignals);
            }

            /*Respuesta tras consultar la estaregia*/
            function setSignals(data)
            {
                console.log('setting...');

                

                /*Si se ejecuto la estrategia correctamente continuamos*/
                if(data.success)
                {
                    console.log('success');
                    /*construir e body de cada tabla*/
                    $.each(data.data_signal, function( code, signal ) 
                    {
                        buildBody(code, signal);
                    });

                    /*si se dieron las condiciones para la senal, notificamos */
                    if(data.general_alert)
                    {
                        console.log('signal found!');
                        var symbol = '<?php echo e($scanner->merged_symbols); ?>';
                        /*notificacion push*/
                        Push.create("Señal en el activo "+symbol, { 
                            body: 'Se ha encontrado una señal en el activo '+ symbol, 
                            timeout: 6000, 
                        });

                        /*disparamos un alert*/    
                        Swal.fire({
                            title: 'Nueva señal encontrada!',
                            type: 'info',
                            toast: true,
                            position: 'top-right',
                            showConfirmButton: false
                        });
                    }
                }   
            }

            /*construye el head de las tablas*/
            function buildHead()
            {    
                <?php $__currentLoopData = $scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    var strategy_table = '<?php echo e($strategy->notification_table); ?>';

                    var table = $('#'+strategy_table);

                    var head = '<tr>';

                    <?php $__currentLoopData = $strategy->notification_fields_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        head = head+'<th><?php echo e($label); ?></th>';

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    head = head+'</tr>';

                    $(table).find('thead').prepend(head);

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }

            /*construye el body de una tabla*/
            function buildBody(code, signal){
                /*table que se llenara con las senales*/
                var table = $('#'+code+'_table');

                /*construimos el nuevo tr*/
                switch (code) {
                        
                    case 'MA_SINGLE':
                        var new_tr = `<tr><td>${signal.symbol}</td><td>${signal.type_html}</td><td>${signal.prev_ma} -> ${signal.ma}</td><td>${signal.prev_price} -> ${signal.price}</td><td>${signal.time}</td></tr>`; 
                    break;
                    case 'MA_DOUBLE':
                        var new_tr = `<tr><td>${signal.symbol}</td><td>${signal.type_html}</td><td>${signal.prev_slow_ma} -> ${signal.slow_ma}</td><td>${signal.prev_fast_ma} -> ${signal.fast_ma}</td><td>${signal.price}</td><td>${signal.time}</td></tr>`; 
                    break;
                    case 'BBANDS':
                        var new_tr = `<tr><td>${signal.symbol}</td><td>${signal.type_html}</td><td>${signal.upper}</td><td>${signal.middle}</td><td>${signal.lower}</td><td>${signal.price}</td><td>${signal.time}</td></tr>`; 
                    break;
                    case 'RSI':
                        var new_tr = `<tr><td>${signal.symbol}</td><td>${signal.type_html}</td><td>${signal.prev_rsi} -> ${signal.rsi}</td><td>${signal.price}</td><td>${signal.time}</td></tr>`; 
                    break;
                    default:
                        var new_tr = `<tr><td>${signal.symbol}</td><td>${signal.type_html}</td><td>${signal.prev_k} -> ${signal.k}</td><td>${signal.prev_d} -> ${signal.d}</td><td>${signal.price}</td><td>${signal.time}</td></tr>`; 
                    break;
                }

                /*si ya tiene 5 registros borramos el ultimo */
                var count_rows = $('#'+code+'_table >tbody >tr').length;
                    
                if(count_rows > 5)
                {
                    console.log('removing...');
                    $('#'+code+'_table >tbody >tr:last').remove();
                }

                /* Escribimos la alerta en la tabla */ 
                console.log('adding...'); 

                $(table).find('tbody').prepend(new_tr);

            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/scanners/show.blade.php ENDPATH**/ ?>