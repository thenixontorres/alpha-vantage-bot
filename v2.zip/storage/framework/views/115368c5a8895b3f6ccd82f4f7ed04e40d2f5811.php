    <div class="form-group row mb-0">

        <div class="form-group col-md-12">
          <?php echo e(Form::label('status','Estatus general del escaner:')); ?>

            <?php echo e(Form::select('status', ['on'=>'On','off'=>'Off'] ,null, ['class'=> 'form-control', 'required'])); ?>

          <small id="statusHelp" class="form-text text-muted">Con estatus Off todas las estrategias y peticiones se detendran.</small>
        </div>
        
        <div class="form-group col-md-12">
            <?php echo e(Form::label('scanners_limit','Cantidad de scanners por usuario:')); ?>

            <?php echo e(Form::number('scanners_limit' ,null, ['class'=> 'form-control', 'required'])); ?> 
        </div>

        <div class="form-group col-md-12">
            <?php echo e(Form::label('notifications_mail','Email de notificaciones:')); ?>

            <?php echo e(Form::email('notifications_mail' ,null, ['class'=> 'form-control', 'required'])); ?>

            <small id="statusHelp" class="form-text text-muted"> Email que recibira las notificaciones luego de una alerta. </small> 
        </div>
        
    </div><?php /**PATH /var/www/html/turtrading/resources/views/admin/settings/fields.blade.php ENDPATH**/ ?>