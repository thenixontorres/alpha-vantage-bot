<div class="form-group row mb-0">
	
	<div class="form-group col-md-12">
        <?php echo e(Form::label('name','Nombre:')); ?>

        <?php echo e(Form::text('name' ,null, ['class'=> 'form-control', 'required'])); ?>

    </div>

    <div class="form-group col-md-12">
        <?php echo e(Form::label('email','Email:')); ?>

        <?php echo e(Form::email('email' ,null, ['class'=> 'form-control', 'required'])); ?>

    </div>

    <div class="form-group col-md-12">
        <?php echo e(Form::label('password','Nueva clave:')); ?>

        <?php echo e(Form::password('password', ['class'=> 'form-control'])); ?>

    </div>

    <div class="form-group col-md-12">
        <?php echo e(Form::label('password_confirmation','Repita su nueva clave:')); ?>

        <?php echo e(Form::password('password_confirmation', ['class'=> 'form-control'])); ?>

    </div>

</div><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/users/fields.blade.php ENDPATH**/ ?>