<table class="table table-bordered table-sm" id="table">
    <thead>
        <tr>
            <th>Llave</th>
            <th>Correo</th>
            <th>Nombre</th>
            <th>Estatus</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	       	<tr>
		        <td><?php echo e($key->key); ?></td>
		        <td><?php echo e($key->email); ?></td>
	       		<td><?php echo e($key->name); ?></td>
	          	<td>
		            <?php if($key->is_active): ?>
		            	<span class="badge badge-success">EN USO</span>
		            <?php else: ?>
		            	<span class="badge badge-warning">APAGADA</span>
		            <?php endif; ?>
		        </td>

	            <td>                              

                <?php if(!$key->is_active): ?>

					         <div class="dropdown">
	                    <button class="btn btn-pill btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	                    <i class="fa fa-gear"></i>
	                    </button>
	                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                              <?php echo Form::model($key, ['route' => ['admin.keys.update', $key], 'method' => 'patch', 'id'=> 'u-'.$key->id]); ?>

                                <a class="dropdown-item" href="#" onclick="update(<?php echo e($key->id); ?>);">Activar llave</a>
                            
                              <?php echo Form::close(); ?>


                              <?php echo Form::open(['route' => ['admin.keys.destroy', $key], 'method' => 'delete', 'id'=> 'd-'.$key->id]); ?>

                              <a class="dropdown-item" href="#" onclick="destroy(<?php echo e($key->id); ?>);">Eliminar llave</a>
                            <?php echo Form::close(); ?>

                           
	                    </div>
	                 </div>
                <?php endif; ?>

	          	</td>
	        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="<?php echo e(asset('js/default_datatable.js')); ?>"></script>

<script type="text/javascript">
    function destroy(id, success = true)
    {
        if (success) {
            Swal.fire({
              title: 'Advertencia',
              text: "Confime que desea borrar esta llave.",
              cancelButtonText: 'Cancelar',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, borrar'
            }).then((result) => {
              if (result.value) {
                destroy(id, false);
              }
            });    
        }else{
            $('#d-'+id).submit();
        }
    }

    function update(id, success = true)
    {
        if (success) {
            Swal.fire({
              title: 'Advertencia',
              text: "Confime que desea activar esta llave.",
              cancelButtonText: 'Cancelar',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, activar'
            }).then((result) => {
              if (result.value) {
                update(id, false);
              }
            });    
        }else{
            $('#u-'+id).submit();
        }
    }
</script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/keys/table.blade.php ENDPATH**/ ?>