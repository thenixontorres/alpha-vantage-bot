<table class="table table-bordered table-sm pt-5" id="<?php echo e($strategy->code); ?>_table">
    <thead>
       
    </thead>
  
    <tbody>
       
    </tbody>
</table><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/scanners/alerts_table.blade.php ENDPATH**/ ?>