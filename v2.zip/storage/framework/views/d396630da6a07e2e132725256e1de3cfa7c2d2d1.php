<table class="table table-bordered table-sm" id="table">
    <thead>
        <tr>
            <th>Simbolo</th>
            
            <th>Estrategia</th>
            <th>Resumen</th>
            <th>Vincular</th>
            <th>Acciones</th>
            <th>Notificaciones</th>
            <th>Escanear</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $scanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($scanner->merged_symbols); ?></td>
            <td>
                <?php $__currentLoopData = $scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php echo Form::open(['route' => ['backoffice.scanners.detachStrategy'], 'id'=> 'd-'.$strategy->id.'-'.$scanner->id]); ?>

                        
                        <?php echo e(Form::hidden('strategy_id', $strategy->id)); ?>

                        
                        <?php echo e(Form::hidden('scanner_id', $scanner->id)); ?>

                    
                        <span class="badge badge-info"><?php echo e($strategy->title); ?> <i class="fa fa-close" onclick="d('<?php echo e($strategy->id); ?>-<?php echo e($scanner->id); ?>');"></i></span>

                    <?php echo Form::close(); ?>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td> 
                <?php $__currentLoopData = $scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('backoffice.strategies.'.$strategy->summary_fields, ['settings_array'=> $scanner->settings_array], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td> 
                <div class="dropdown">
                    <button class="btn btn-pill btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-bar-chart"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <?php $__currentLoopData = $strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php echo e(Form::open(['route'=>'backoffice.scanners.attachStrategy', 'id'=>'a-'.$strategy->id.'-'.$scanner->id])); ?>


                                <?php echo e(Form::hidden('strategy_id', $strategy->id)); ?>


                                <?php echo e(Form::hidden('scanner_id', $scanner->id)); ?>

                            
                            <?php echo e(Form::close()); ?>


                            <a class="dropdown-item" onclick="event.preventDefault();document.getElementById('a-<?php echo e($strategy->id); ?>-<?php echo e($scanner->id); ?>').submit();" href="#"><?php echo e($strategy->title); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </td>
            <td> 
                <div class="dropdown">
                    <button class="btn btn-pill btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-gear"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        
                        <a class="dropdown-item" href="<?php echo e(route('backoffice.scanners.edit', [$scanner])); ?>">Configurar escaner</a>

                        <?php echo Form::open(['route' => ['backoffice.scanners.destroy', $scanner], 'method' => 'delete', 'id'=> 'del-'.$scanner->id]); ?>

                            <a class="dropdown-item" href="#" onclick="del('<?php echo e($scanner->id); ?>');">Eliminar escaner</a>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </td>
            <td>
                <?php if(!empty($scanner->strategies->first())): ?>

                    <?php echo Form::model($scanner, ['route' => ['backoffice.scanners.updateStatus', $scanner], 'method' => 'patch']); ?>


                        <?php if($scanner->status == 'on'): ?>
                            <?php echo e(Form::hidden('status', 'off')); ?>

                            <button class="btn btn-pill btn-success"><i class="fa fa-play"></i></button>
                        <?php else: ?>
                            <?php echo e(Form::hidden('status', 'on')); ?>

                            <button class="btn btn-pill btn-warning"><i class="fa fa-stop"></i></button>
                        <?php endif; ?>
                        
                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <button class="btn btn-pill btn-secondary"><i class="fa fa-stop"></i></button>
                <?php endif; ?>
            </td>
            <td> 
                <?php if(!empty($scanner->strategies->first())): ?>
                    <a href="<?php echo e(route('backoffice.scanners.show', $scanner)); ?>" class="btn btn-pill btn-primary"><i class="fa fa-eye"></i></a>
                <?php else: ?>
                    <button class="btn btn-pill btn-secondary"><i class="fa fa-eye"></i></button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table> 

<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<script src="<?php echo e(asset('js/default_datatable.js')); ?>"></script>

<script type="text/javascript">
    function d(id, success = true)
    {
        if (success) {
            Swal.fire({
              title: 'Advertencia',
              text: "Confime que desea desvincular esta estrategia.",
              cancelButtonText: 'Cancelar',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, desvincular'
            }).then((result) => {
              if (result.value) {
                d(id, false);
              }
            });    
        }else{
            $('#d-'+id).submit();
        }
    }
    function del(id, success = true)
    {
        if (success) {
            Swal.fire({
              title: 'Advertencia',
              text: "Confime que desea borrar este escaner.",
              cancelButtonText: 'Cancelar',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, borrar'
            }).then((result) => {
              if (result.value) {
                del(id, false);
              }
            });    
        }else{
            $('#del-'+id).submit();
        }
    }
</script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/scanners/table.blade.php ENDPATH**/ ?>