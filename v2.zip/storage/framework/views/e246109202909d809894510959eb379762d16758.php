
<p>
	<strong> Temporalidad:  </strong> <?php echo e($settings_array['RSI']['request_data']['interval']); ?></strong>
</p>

<p>
	<strong> Peridos:  </strong> <?php echo e($settings_array['RSI']['request_data']['time_period']); ?></strong>
</p>

<?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/RSI_summary_fields.blade.php ENDPATH**/ ?>