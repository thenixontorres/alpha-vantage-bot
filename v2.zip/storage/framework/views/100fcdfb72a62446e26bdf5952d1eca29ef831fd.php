<p>
	<strong> Temporalidad:  </strong> <?php echo e($settings_array['STOCH']['request_data']['interval']); ?></strong>
</p>

<p>
	<strong> K:  </strong> <?php echo e($settings_array['STOCH']['request_data']['slowkperiod']); ?></strong>
</p>

<p>
	<strong> D:  </strong> <?php echo e($settings_array['STOCH']['request_data']['slowdperiod']); ?></strong>
</p>

<p>
	<strong> Smooth:  </strong> <?php echo e($settings_array['STOCH']['request_data']['fastkperiod']); ?></strong>
</p>


<?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/STOCH_summary_fields.blade.php ENDPATH**/ ?>