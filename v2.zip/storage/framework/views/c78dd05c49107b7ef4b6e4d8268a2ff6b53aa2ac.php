
<p>
	<strong> Temporalidad:  </strong> <?php echo e($settings_array['MA_SINGLE']['request_data']['interval']); ?></strong>
</p>


<p>
	<strong> MA:  </strong> <?php echo e($settings_array['MA_SINGLE']['request_data']['function']); ?> / <?php echo e($settings_array['MA_SINGLE']['request_data']['time_period']); ?> </strong>
</p>

<?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/MA_SINGLE_summary_fields.blade.php ENDPATH**/ ?>