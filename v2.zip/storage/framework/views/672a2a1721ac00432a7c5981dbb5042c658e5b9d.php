<?php $__env->startSection('title', 'Llaves'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center pb-4">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-header border-0">
                    <div class="custom-title-wrap bar-info">
                        <div class="custom-title">Registrar llave</div>
                    </div>
                  </div>
                  <div class="card-body">
                      <?php echo Form::open(['route'=>'admin.keys.store']); ?>

                        
                        <div class="form-group row mb-0">
    
                          <?php echo $__env->make('admin.keys.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <div class="form-group row mb-0">
                          <div class="col-md-12">
                              <center>  
                                  <button type="submit" class="btn btn-pill btn-primary">
                                      Registrar
                                  </button>
                              </center>
                          </div>
                        </div>

                      <?php echo Form::close(); ?>

                  </div>
              </div>
          </div>
    </div>

    <div class="row justify-content-center" >
        <div class="col-md-12">
            <div class="card">
                <div class="card-header border-0">
                  <div class="custom-title-wrap bar-info">
                      <div class="custom-title">Lista de Llaves</div>
                  </div>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.keys.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/keys/index.blade.php ENDPATH**/ ?>