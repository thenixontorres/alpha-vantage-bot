<?php $__env->startSection('title', 'Escaners'); ?>

<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link href="<?php echo e(asset('vendor/select2/css/select2.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	
	<?php if($type != 'all'): ?>
	<div class="row justify-content-center pb-4">
        <div class="col-md-12">
            <div class="card">
				<div class="card-header border-0">
                  <div class="custom-title-wrap bar-info">
                      <div class="custom-title">Registrar escaner</div>
                  </div>
                </div>
                <div class="card-body">
					<?php echo Form::open(['route'=>'admin.scanners.store']); ?>


	                	<?php if($type == 'stock_market'): ?>
							
							<?php echo $__env->make('admin.scanners.stock_market_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	                    <?php elseif($type == 'physical'): ?>
							
							<?php echo $__env->make('admin.scanners.physical_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						
						<?php elseif($type == 'digital'): ?>

							<?php echo $__env->make('admin.scanners.digital_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	                    <?php endif; ?>

	                    <?php echo e(Form::hidden('scanner_type', $type)); ?>


						<div class="form-group row mb-0">
		                    <div class="col-md-12">
		                          <center>  
		                              <button type="submit" class="btn btn-pill btn-primary">
		                                  Registrar
		                              </button>
		                          </center>
	                      	</div>
	                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
	<?php endif; ?>

    <div class="row justify-content-center pb-4">
        <div class="col-md-12">
            <div class="card">
				<div class="card-header border-0">
                  <div class="custom-title-wrap bar-info">
                      <div class="custom-title">Lista de escaners</div>
                  </div>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.scanners.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="<?php echo e(asset('vendor/select2/js/select2.min.js')); ?>"></script>
<script>
	$(document).ready(function() {
	    $('.select2').select2();
	});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/scanners/index.blade.php ENDPATH**/ ?>