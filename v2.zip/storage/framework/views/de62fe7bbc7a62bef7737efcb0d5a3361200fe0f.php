

<div class="form-group col-md-12">
	<?php echo e(Form::label('interval','Temporalidad de la gráfica:')); ?>

    <?php echo e(Form::select('interval', $intervals , $scanner->interval, ['class'=> 'form-control', 'placeholder'=>'Seleccione un intervalo','required'])); ?>

</div><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/GENERAL_setting_fields.blade.php ENDPATH**/ ?>