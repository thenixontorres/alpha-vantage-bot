<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!--favicon icon-->
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>">

    <title><?php echo $__env->yieldContent('title', 'TURTRADING'); ?></title>

    <!--web fonts-->
    <link href="//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <!--bootstrap styles-->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!--icon font-->
    <link href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/dashlab-icon/dashlab-icon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/simple-line-icons/css/simple-line-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/themify-icons/css/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/weather-icons/css/weather-icons.min.css')); ?>" rel="stylesheet">

    <!--custom scrollbar-->
    <link href="<?php echo e(asset('vendor/m-custom-scrollbar/jquery.mCustomScrollbar.css')); ?>" rel="stylesheet">

    <!--jquery dropdown-->
    <link href="<?php echo e(asset('vendor/jquery-dropdown-master/jquery.dropdown.css')); ?>" rel="stylesheet">

    <!--jquery ui-->
    <link href="<?php echo e(asset('vendor/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('vendor/data-tables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    <!--custom styles-->
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">

    <!-- swewt alert -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.css')); ?>"/>

    <?php echo $__env->yieldContent('css'); ?>
</head>


<body class="fixed-nav top-nav">

    <!--header-->
    <?php echo $__env->make("admin.elements.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make("admin.elements.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

    <!--main content wrapper-->
    <div class="content-wrapper">

        <?php echo $__env->yieldContent('content'); ?>
        
    </div>
    <!--/main content wrapper-->

    <!--footer-->
    <?php echo $__env->make("admin.elements.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--/footer-->
    
    <?php echo $__env->yieldContent('modals'); ?>
    
    <!--basic scripts-->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery-dropdown-master/jquery.dropdown.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/m-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
   
    <!--datatables-->
    <script src="<?php echo e(asset('vendor/data-tables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/data-tables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!--basic scripts initialization-->
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>

    <!-- vendor -->
    <script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.all.js')); ?>"></script>
    
    
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    <?php if(isset($errors)): ?>
        <?php if(count($errors) > 0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <script>
                    Swal.fire({
                      type: 'error',
                      title: '<?php echo e($error); ?>',
                      toast: true,
                      position: 'top-right',
                      showConfirmButton: false  
                    });
                </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endif; ?>
    
    <?php echo $__env->yieldContent('js'); ?>

</body>
</html>
<?php /**PATH /var/www/html/turtrading/resources/views/layouts/admin.blade.php ENDPATH**/ ?>