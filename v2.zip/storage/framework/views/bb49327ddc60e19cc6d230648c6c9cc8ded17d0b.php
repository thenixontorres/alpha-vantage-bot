<p>
	<strong> Temporalidad:  </strong> <?php echo e($settings_array['BBANDS']['request_data']['interval']); ?></strong>
</p>

<p>
	<strong> Peridos:  </strong> <?php echo e($settings_array['BBANDS']['request_data']['time_period']); ?></strong>
</p>

<p>
	<strong> Banda alta:  </strong> <?php echo e($settings_array['BBANDS']['request_data']['nbdevup']); ?></strong>
</p>

<p>
	<strong> Banda baja:  </strong> <?php echo e($settings_array['BBANDS']['request_data']['nbdevdn']); ?></strong>
</p><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/BBANDS_summary_fields.blade.php ENDPATH**/ ?>