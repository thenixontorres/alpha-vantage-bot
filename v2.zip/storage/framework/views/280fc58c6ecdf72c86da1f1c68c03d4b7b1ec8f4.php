<table class="table table-bordered table-sm" id="table">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Tipo</th>
            <th>Escaners</th>
            <th>Alertas</th>
            <th>Estatus</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       		<tr>
	          	<td><?php echo e($user->name); ?></td>
	          	<td><?php echo e($user->email); ?></td>
	          	<td><span class="badge badge-info"><?php echo e($user->type); ?></span></td>
            	<td><?php echo e($user->scanners->count()); ?></td>
            	<td><?php echo e($user->count_signals); ?></td>       		
		        <td>
		            <?php if($user->status == 'active'): ?>
		            <span class="badge badge-success">ACTIVO</span>
		            <?php else: ?>
		            <span class="badge badge-danger">INACTIVO</span>
		            <?php endif; ?>
		        </td>
		        <td>
		        	<div class="dropdown">
	                    <button class="btn btn-pill btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	                    <i class="fa fa-gear"></i>
	                    </button>
	                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
	                        
	                        <a class="dropdown-item" href="<?php echo e(route('admin.users.edit', [$user])); ?>">Editar</a>

	                        <?php echo Form::open(['route' => ['admin.users.destroy', $user], 'method' => 'delete', 'id'=> 'del-'.$user->id]); ?>

	                            <a class="dropdown-item" href="#" onclick="del('<?php echo e($user->id); ?>');">Eliminar</a>
	                        <?php echo Form::close(); ?>

	                    </div>
	                </div>
		        </td>

          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="<?php echo e(asset('js/default_datatable.js')); ?>"></script>
<script>
	function del(id, success = true)
	{
	    if (success) {
	        Swal.fire({
	          title: 'Advertencia',
	          text: "Confime que desea borrar este escaner.",
	          cancelButtonText: 'Cancelar',
	          showCancelButton: true,
	          confirmButtonColor: '#3085d6',
	          cancelButtonColor: '#d33',
	          confirmButtonText: 'Si, borrar'
	        }).then((result) => {
	          if (result.value) {
	            del(id, false);
	          }
	        });    
	    }else{
	        $('#del-'+id).submit();
	    }
	}
</script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/users/table.blade.php ENDPATH**/ ?>