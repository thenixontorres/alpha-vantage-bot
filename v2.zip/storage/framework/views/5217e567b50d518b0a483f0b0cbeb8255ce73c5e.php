<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright &copy; TurTrading 2019</small>
        </div>
    </div>
</footer><?php /**PATH /var/www/html/turtrading/resources/views/admin/elements/footer.blade.php ENDPATH**/ ?>