<table class="table table-bordered table-sm" id="table">
    <thead>
        <tr>
            <th>Fecha</th>
            <th>Activo</th>
            <th>Estrategia</th>
            <th>Resumen</th>
            <th>Tipo</th>
            <th>Estatus</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $signals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       		<tr>
          <td><?php echo e($signal->time_signal); ?></td>
       		<td><?php echo e($signal->scanner->merged_symbols); ?></td>
       		<td>
       			<?php $__currentLoopData = $signal->scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                 <span class="badge badge-info"><?php echo e($strategy->title); ?> </span>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       		</td>
       		<td>
       			<?php $__currentLoopData = $signal->scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('backoffice.strategies.'.$strategy->summary_fields, ['settings_array'=> $signal->scanner->settings_array], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       		</td>
       		<td>
       			<?php echo $signal->type; ?>

       		</td>
          <td>
            <?php if($signal->status == 'ignored'): ?>
            <span class="badge badge-secondary">IGNORADA</span>
            <?php elseif($signal->status == 'success'): ?>
            <span class="badge badge-success">CORRECTA</span>
            <?php else: ?>
            <span class="badge badge-danger">FALLIDA</span>
            <?php endif; ?>
          </td>
          <td>

            <?php if($signal->status == 'ignored'): ?>
              
            <?php echo Form::model($signal, ['route' => ['backoffice.signals.update', $signal], 'method' => 'patch']); ?>


              <?php echo Form::hidden('status', 'success'); ?>

              
              <button class="btn btn-pill btn-success"><i class="fa fa-check"></i></button>

            <?php echo Form::close(); ?>


            <?php echo Form::model($signal, ['route' => ['backoffice.signals.update', $signal], 'method' => 'patch']); ?>


              <?php echo Form::hidden('status', 'failed'); ?>

              
              <button class="btn btn-pill btn-danger"><i class="fa fa-close"></i></button>
              
            <?php echo Form::close(); ?>


            <?php endif; ?>
          </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="<?php echo e(asset('js/default_datatable.js')); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/signals/table.blade.php ENDPATH**/ ?>