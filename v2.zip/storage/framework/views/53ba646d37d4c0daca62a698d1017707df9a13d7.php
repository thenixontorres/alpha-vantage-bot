<?php $__env->startSection('title', 'Editar '.$scanner->merged_symbols); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h4> <?php echo e($scanner->merged_symbols); ?> </h4>
        </div>
        <div class="col-md-12 pb-4">

            <div class="card">
                <div class="card-header border-0">
                    <div class="custom-title-wrap bar-info">
                        <div class="custom-title">General</div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">

                            <?php echo Form::model($scanner, ['route' => ['admin.scanners.update', $scanner], 'method' => 'patch']); ?>

                                
                                <div class="form-group row mb-0">
                                
                                    <?php echo $__env->make('backoffice.strategies.GENERAL_setting_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                                </div>

                                <div class="form-group row mb-0">
                                    <div class="col-md-12">
                                        <center>  
                                            <button type="submit" class="btn btn-pill btn-primary">
                                                Actualizar
                                            </button>
                                        </center>
                                    </div>
                                </div>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>
        <?php $__currentLoopData = $scanner->strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 pb-4">

                <div class="card">
                    <div class="card-header border-0">
                        <div class="custom-title-wrap bar-info">
                            <div class="custom-title">   
                                Estrategia: 
                                <span class="badge badge-info"> <?php echo e($strategy->title); ?></span> 
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
    	                  	<div class="col-md-12">

                                <?php echo Form::model($scanner, ['route' => ['admin.scanners.updateSettings', $scanner], 'method' => 'patch']); ?>

                                    
                                    <div class="form-group row mb-0">
                                    
                                        <?php echo $__env->make('backoffice.strategies.'.$strategy->setting_fields, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    
                                    </div>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-12">
                                            <center>  
                                                <button type="submit" class="btn btn-pill btn-primary">
                                                    Actualizar
                                                </button>
                                            </center>
                                        </div>
                                    </div>

                                <?php echo Form::close(); ?>

    						</div>
                        </div>
                    </div>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="col-md-12 pt-4 pb-4">
            <a class="btn btn-pill btn-danger" href="<?php echo e(route('admin.scanners.index', $scanner->scanner_type)); ?>">Volver</a>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/scanners/edit.blade.php ENDPATH**/ ?>