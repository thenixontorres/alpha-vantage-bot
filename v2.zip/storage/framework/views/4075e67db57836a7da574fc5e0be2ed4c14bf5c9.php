<?php $__env->startSection('title', 'Estrategias'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center" >
        <div class="col-md-12">
            <div class="card">
                <div class="card-header border-0">
                  <div class="custom-title-wrap bar-info">
                      <div class="custom-title">Lista de estrategias</div>
                  </div>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.strategies.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/strategies/index.blade.php ENDPATH**/ ?>