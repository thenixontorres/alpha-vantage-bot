<div class="form-group col-md-12">
  <?php echo e(Form::text('key', null, ['class'=> 'form-control typeahead', 'placeholder'=>'Llave','required',])); ?>

</div>

<div class="form-group col-md-12">
  <?php echo e(Form::text('email', null, ['class'=> 'form-control typeahead', 'placeholder'=>'Correo','required',])); ?>

</div>

<div class="form-group col-md-12">
  <?php echo e(Form::text('name', null, ['class'=> 'form-control typeahead', 'placeholder'=>'Nombre','required',])); ?>

</div><?php /**PATH /var/www/html/turtrading/resources/views/admin/keys/fields.blade.php ENDPATH**/ ?>