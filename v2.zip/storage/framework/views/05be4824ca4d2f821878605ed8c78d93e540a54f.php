
<p>
	<strong> Temporalidad:  </strong> <?php echo e($settings_array['MA_DOUBLE']['request_data']['interval']); ?></strong>
</p>

<p>
	<strong> MA Lenta:  </strong> <?php echo e($settings_array['MA_DOUBLE']['request_data']['slow']['function']); ?> / <?php echo e($settings_array['MA_DOUBLE']['request_data']['slow']['time_period']); ?> </strong>
</p>

<p>
	<strong> MA Rapida:  </strong> <?php echo e($settings_array['MA_DOUBLE']['request_data']['fast']['function']); ?> / <?php echo e($settings_array['MA_DOUBLE']['request_data']['fast']['time_period']); ?> </strong>
</p><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/MA_DOUBLE_summary_fields.blade.php ENDPATH**/ ?>