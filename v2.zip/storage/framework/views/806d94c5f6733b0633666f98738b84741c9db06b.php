<table class="table table-bordered table-sm" id="table">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Símbolo</th>
            <th>Estatus</th>
            <th>Tipo</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($asset->name); ?></td>
            <td><?php echo e($asset->symbol); ?></td>
            <td>
                <?php if($asset->status  == 'on'): ?>
                <span class="badge badge-success">
                Activo
                <?php else: ?>
                <span class="badge badge-warning">
                Inactivo
                <?php endif; ?>
                </span>
            </td>
            <td>
                <span class="badge badge-info">
                <?php if($asset->type  == 'digital'): ?>
                Digital
                <?php elseif($asset->type == 'physical'): ?>
                Fisica
                <?php else: ?>
                Acciones
                <?php endif; ?>
                </span>
            </td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-pill btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-gear"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <?php if($asset->status  == 'on'): ?>
                        <?php echo Form::open(['route' => 'admin.assets.changeStatus', 'id'=> 'des-'.$asset->id]); ?>

                        <?php echo e(Form::hidden('id', $asset->id)); ?>

                        <?php echo e(Form::hidden('status', 'off')); ?>

                        <a class="dropdown-item" href="#" onclick="des(<?php echo e($asset->id); ?>);">Desactivar</a>
                        <?php echo Form::close(); ?>

                        <?php else: ?>
                        <?php echo Form::open(['route' => 'admin.assets.changeStatus', 'id'=> 'ac-'.$asset->id]); ?>

                        <?php echo e(Form::hidden('id', $asset->id)); ?>

                        <?php echo e(Form::hidden('status', 'on')); ?>

                        <a class="dropdown-item" href="#" onclick="ac(<?php echo e($asset->id); ?>);">Activar</a>
                        <?php echo Form::close(); ?>              
                        <?php endif; ?>
                        
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<script src="<?php echo e(asset('js/default_datatable.js')); ?>"></script>

<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/turtrading/resources/views/admin/assets/table.blade.php ENDPATH**/ ?>