
<div class="form-group col-md-4">
	<?php echo e(Form::label('series_type','Tipo de precio:')); ?>

    <?php echo e(Form::select('series_type', $series ,$scanner->settings_array['MA_SINGLE']['request_data']['series_type'], ['class'=> 'form-control', 'placeholder'=>'Seleccione un tipo','required'])); ?>

</div>

<div class="form-group col-md-4">
	<?php echo e(Form::label('function','Tipo de MA:')); ?>

    <?php echo e(Form::select('function',  $scanner->settings_array['MA_SINGLE']['indicators_allow'] ,$scanner->settings_array['MA_SINGLE']['request_data']['function'], ['class'=> 'form-control', 'placeholder'=>'Seleccione un tipo','required'])); ?>

</div>

<div class="form-group col-md-4">
	<?php echo e(Form::label('time_period','Periodos:')); ?>

    <?php echo e(Form::number('time_period' ,$scanner->settings_array['MA_SINGLE']['request_data']['time_period'], ['class'=> 'form-control', 'placeholder'=>'Solo numeros enteros', 'required'])); ?>

</div>



<?php echo e(Form::hidden('symbol', $scanner->settings_array['MA_SINGLE']['request_data']['symbol'])); ?>


<?php echo e(Form::hidden('interval', $scanner->settings_array['MA_SINGLE']['request_data']['interval'])); ?>


<?php echo e(Form::hidden('code', 'MA_SINGLE')); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/strategies/MA_SINGLE_setting_fields.blade.php ENDPATH**/ ?>