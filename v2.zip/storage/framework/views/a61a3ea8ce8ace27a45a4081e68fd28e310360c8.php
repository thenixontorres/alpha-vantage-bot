<?php $__env->startSection('title', 'Mis cuenta'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center" >
        <div class="col-md-12">
            <div class="card">
                <div class="card-header border-0">
                    <div class="custom-title-wrap bar-info">
                        <div class="custom-title">Mi cuenta</div>
                    </div>
                </div>
                <div class="card-body">
                  <?php echo Form::model(Auth::user(), ['route' => ['backoffice.users.update', Auth::user()], 'method' => 'patch']); ?>

                      
                    <?php echo $__env->make('backoffice.users.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <div class="form-group row mb-0">
                      <div class="col-md-12">
                          <center>  
                              <a class="btn btn-danger form-pill" href="<?php echo e(route('backoffice.index')); ?>">Volver</a>
                              <button type="submit" class="btn btn-primary form-pill">
                                  Actualizar
                              </button>
                          </center>
                      </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/users/index.blade.php ENDPATH**/ ?>