<?php $__env->startSection('title', 'Mis alertas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center" >
        <div class="col-md-12">
            <div class="card">
                <div class="card-header border-0">
                    <div class="custom-title-wrap bar-info">
                        <div class="custom-title">Mis alertas</div>
                    </div>
                </div>                
                <div class="card-body">
                    <?php echo $__env->make('backoffice.signals.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
    
   <script> 
        $(document).ready(function(){

            console.log('starting...');
            
            
            setInterval(updateSignals, 60000);

            /*Consulta de la estrategia*/
            function updateSignals()
            {
                location.reload();
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/turtrading/resources/views/backoffice/signals/index.blade.php ENDPATH**/ ?>